from flask import Flask,render_template,request
import MySQLdb
import redis
from random import randint
import time
import hashlib
import cPickle
app = Flask(__name__)

@app.route('/',methods=['POST','GET'])
def hello_world():
    return render_template("index.html")

@app.route('/upload',methods=['POST'])
def upload():
    return render_template("Result.html")

@app.route('/randomquery',methods=['POST','GET'])
def random_query():
    if request.method=='POST':
        size=request.form['random_query']
        print size
        db = MySQLdb.connect("####", "####", "####","#####");
        print "Connection successful"
        cursor = db.cursor();
        total_time=0
        start_time=time.time()
        print start_time
        for num in range(1,int(size)):
            #randamt=randint(454500,525200)
            sql_select="SELECT * FROM complaints ORDER BY RAND() LIMIT 5000";
            cursor.execute(sql_select)
        end_time=time.time()
        print end_time
        db.close()
        total_time=end_time-start_time
        print total_time
    return render_template("Result.html",message=total_time)

@app.route('/fixedquery',methods=['POST'])
def fixed_query():
    size=request.form['fixed_query']
    print size
    db = MySQLdb.connect("####", "####", "####","####");
    print "Connection successful"
    cursor = db.cursor();
    total_time=0
    start_time = time.time()
    print start_time
    for num in range(1, int(size)):
        comp_id = randint(454500, 460000)
        sql_select1 = "SELECT Sub_Product FROM complaints WHERE Product='Mortgage' AND Complaint_ID="+ str(comp_id);
        cursor.execute(sql_select1)
    end_time = time.time()
    print end_time
    db.close()
    total_time = end_time - start_time
    print total_time
    return render_template("Result.html", message=total_time)


@app.route('/randomquerycache',methods=['POST'])
def random_cquery():
    count=request.form['random_cquery']
    print count
    db = MySQLdb.connect("####", "####", "####","####");
    print "Connected to rds"
    conn=redis.ConnectionPool(host='####',port='6379',db=0)
    redis_con=redis.Redis(connection_pool=conn)
    #redis_con = redis.Redis('localhost')
    print "Connected to cache"

    start_time = time.time()
    for i in range(1,int(count)):
        #sql_select= "SELECT * FROM complaints WHERE Product='Mortgage' ORDER BY RAND() LIMIT 10" ;
        comp_id = randint(454500, 460000)
        sql_select = "SELECT Sub_Product FROM complaints WHERE Product='Mortgage' AND Complaint_ID=" + str(comp_id);
        # hashing the sql query as key
        hash_query=hashlib.md5(sql_select.encode())
        hash_key=hash_query.hexdigest()
        #checking the cache
        if(redis_con.get(hash_key)):
            print "Retrieved the result from cache"

        else:
            cursor = db.cursor()
            cursor.execute(sql_select)
            sql_result = cursor.fetchall()
            print sql_result
            cache_insert = redis_con.set(hash_key, cPickle.dumps(sql_result))
    end_time = time.time()
    total_time = end_time - start_time
    print total_time
    print "Retrieved from sql"
    return render_template('Result.html', message=total_time)


@app.route('/fixedquerycache',methods=['POST'])
def fixed_cquery():
    count=request.form['fixed_cquery']
    print count
    db = MySQLdb.connect("####", "####", "####","####");
    print "Connected to rds"
    conn=redis.ConnectionPool(host='####',port='6379',db=0)
    redis_con=redis.Redis(connection_pool=conn)
    print "Connected to cache"
    start_time = time.time()
    for i in range(1,int(count)):
        comp_id = randint(454500, 460000)
        sql_select1 = "SELECT Sub_Product FROM complaints WHERE Product='Mortgage' AND Complaint_ID=" + str(comp_id);
        # hashing the sql query as key
        hash_query=hashlib.md5(sql_select1.encode())
        hash_key=hash_query.hexdigest()

        #checking the cache
        if(redis_con.get(hash_key)):
            print "Retrieved the result from cache"

        else:
            cursor = db.cursor()
            cursor.execute(sql_select1)
            sql_result = cursor.fetchall()
            print sql_result
            cache_insert = redis_con.set(hash_key, cPickle.dumps(sql_result))
    end_time = time.time()
    total_time = end_time - start_time
    print total_time
    print "Retrieved from sql"
    return render_template('Result.html', message=total_time)



if __name__ == '__main__':
    app.debug = 'true'
    app.run()